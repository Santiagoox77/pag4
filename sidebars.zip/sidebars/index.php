<script>
  window.onload = function(){
  window.location.href ="public/index.php"
};
</script>