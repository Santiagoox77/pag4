<ul class="nav nav-pills flex-column mb-auto">
      <li class="nav-item">
        <a href="index.php" class="nav-link active" aria-current="page">
          <svg class="bi pe-none me-2" width="16" height="16"><use xlink:href="#home"/></svg>
          INICIO
        </a>
      </li>
      <li>
        <a href="perfi.php" class="nav-link text-white">
          <svg class="bi pe-none me-2" width="16" height="16"><use xlink:href="#speedometer2"/></svg>
          PERFIL
        
        </a>
        
      </li>
      <li>
        <a href="reels.php" class="nav-link text-white">
          <svg class="bi pe-none me-2" width="16" height="16"><use xlink:href="#table"/></svg>
          REELS
        </a>
      </li>
      <li>
        <a href="mer.php" class="nav-link text-white">
          <svg class="bi pe-none me-2" width="16" height="16"><use xlink:href="#grid"/></svg>
          MERKTPLACE
        </a>
      </li>
      <li>
        <a href="confi.php" class="nav-link text-white">
          <svg class="bi pe-none me-2" width="16" height="16"><use xlink:href="#people-circle"/></svg>
          CONFIGURACION
        </a>
      </li>
      
    </ul>